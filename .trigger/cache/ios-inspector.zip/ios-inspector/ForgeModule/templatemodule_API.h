#import <Foundation/Foundation.h>

@interface templatemodule_API : NSObject

// There is no requirement to declare your API methods in this file,
// unless you wish to call them from other native code.

@end
